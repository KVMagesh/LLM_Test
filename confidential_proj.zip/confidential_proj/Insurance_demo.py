# -*- coding: utf-8 -*-
"""
Created on Tue Jul 18 11:44:29 2023

@author: Mahesh
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Jul  6 19:38:39 2023

@author: Mahesh
"""
from langchain.document_loaders import PyPDFDirectoryLoader
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import gradio as gr
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.chains import ConversationalRetrievalChain
from langchain.chat_models import ChatOpenAI
import fitz,os,uuid
from PIL import Image
import os.path
#from dotenv import load_dotenv, find_dotenv

class my_app:
    def __init__(self, OPENAI_API_KEY= None ) -> None:
          self.N = 0
          self.sel_kdb=''
          self.chat_history = []
          self.context='' 

def add_text(history,text):
    if not text:
         raise gr.Error('enter text')
    history = history + [(text,'')] 
    return history

def get_collections():
    folder = './Knowledge Base'
    collections = [name for name in os.listdir(folder) if os.path.isdir(os.path.join(folder, name))]
    return collections

def selected_kdb(kdb):
        print('selected kdb',kdb)
        app.sel_kdb=kdb
        return kdb

def all_lower(my_list):
    return [x.lower() for x in my_list]

def check_query(sel_kdb,query):
    check=False
    
    if sel_kdb=="Car_Insurance":
       x="car" 
    elif sel_kdb=="Home_Insurance":
       x="home" 
       
    stop_words = set(stopwords.words('english'))
    word_tokens = word_tokenize(query)
    filtered_sentence = [w for w in word_tokens if not w.lower() in stop_words]
    filtered_sentence = []
     
    for w in word_tokens:
        if w not in stop_words:
            filtered_sentence.append(w)
    filtered_sentence=all_lower(filtered_sentence) 
    #print(filtered_sentence)
    
    for item in filtered_sentence:
        if item==x:   
           check=True
    return check        
    
def get_response(history, query, file):
     app.context=''
     result={}
     print('app.sel_kdb --------------------->',app.sel_kdb)
     check=check_query(app.sel_kdb,query)
     if check:
         collection_name=app.sel_kdb
         persist_directory="./Knowledge Base/"+collection_name
         embedding_function = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY) 
         db = Chroma(persist_directory=persist_directory,collection_name=collection_name,embedding_function=embedding_function)
         #ans=db.similarity_search(query,k=1),'gpt-3.5-turbo'
         chain = ConversationalRetrievalChain.from_llm(ChatOpenAI(temperature=0.0,model_name='gpt-3.5-turbo', openai_api_key=OPENAI_API_KEY),
                                                  retriever=db.as_retriever())
         result = chain({"question": query,'chat_history':app.chat_history},return_only_outputs=True)
         print(result,type(result))
     else:
         x="Sorry I don't know.Since you have selected "+app.sel_kdb+ " knowledge base, I would be able to answer any queries specific to that context.Can you please rephrase your query so that I can help you better"
         result.update({"answer":x})

         
     app.chat_history += [(query, result["answer"])]
     for char in result['answer']:
         history[-1][-1] += char
     yield history,''
      
app = my_app()      

OPENAI_API_KEY="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"


with gr.Blocks() as demo:
    state = gr.State(uuid.uuid4().hex)
    with gr.Row():
        
        with gr.Column(scale=0.50):
            with gr.Row(scale=0.10):
                  collections=get_collections()
                  value = gr.Dropdown(choices=collections,label="KnowledgeBase")
            with gr.Row(scale=0.80):
                  txt = gr.Textbox(
                        show_label=False,lines=18,
                        placeholder="Enter Your Query to get the answer ",
                        ) 
            with gr.Row(scale=0.10):
                  submit_btn = gr.Button('Submit your Query').style(height=10)
        with gr.Column(scale=0.50):
            with gr.Row(scale=0.95):   
                  chatbot = gr.Chatbot(elem_id='chatbot').style(height=350)
        
    value.change(fn=selected_kdb, inputs=value,outputs=[])
    submit_btn.click(fn=add_text, inputs=[chatbot,txt], outputs=[chatbot, ], queue=False).success(fn=get_response,inputs = [chatbot, txt],
                                    outputs = [chatbot,txt])     
demo.queue()
demo.launch(share=True)  