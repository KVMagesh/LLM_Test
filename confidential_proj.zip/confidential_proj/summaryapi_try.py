# -*- coding: utf-8 -*-
"""
Created on Thu Jul 27 18:18:41 2023

@author: Mahesh
"""
import json
from langchain.chat_models import ChatOpenAI
from langchain import PromptTemplate
from langchain.chains import LLMChain
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.agents.agent_toolkits import create_python_agent
from langchain.tools.python.tool import PythonREPLTool  

# Sri hari key
OPENAI_API_KEY="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"
# Magesh key
#OPENAI_API_KEY="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"
#OPENAI_API_KEY="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"
llm = ChatOpenAI(temperature=0, openai_api_key=OPENAI_API_KEY,model_name='gpt-3.5-turbo')

query='can you get me quote for my car rc number TN07CM7990'
#1
template = """Extract the entities and corresponding values from the following {query} and describe the intent of the {query}.Then create a key value pair of the extracted entities and intent as Json """
prompt = PromptTemplate(
    input_variables=['query'],
    template=template
)
chain = LLMChain(llm=llm, prompt=prompt)
output_summary = chain.run({'query':query})
output_summary=json.loads(output_summary)
data=output_summary
print(data)

intent=output_summary["intent"] + ' get api url'
collection_name='api'
persist_directory="./Knowledge Base/"+collection_name
embedding_function = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY) 
db = Chroma(persist_directory=persist_directory,collection_name=collection_name,embedding_function=embedding_function)
result = db.similarity_search(intent)
template = """Extract the URL,Method and Inputs from {result} and replace the API input parameters only with value of the {data}. Then show me only the final result as JSON with keys renamed as 'api','method','inputs'"""
prompt = PromptTemplate(
      input_variables=['result','data'],
      template=template
)
chain = LLMChain(llm=llm, prompt=prompt)
output_summary = chain.run({'result':result,'data':data})
output_summary=json.loads(output_summary)
print(output_summary)
'''
#2
intent=output_summary["intent"] + ' get api url'
collection_name='api'
persist_directory="./Knowledge Base/"+collection_name
embedding_function = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY) 
db = Chroma(persist_directory=persist_directory,collection_name=collection_name,embedding_function=embedding_function)
result = db.similarity_search(intent)
print(result)
template = """Extract URL,Method,Inputs from {result} matching the {intent} and replace the API input parameters only with value of the {data}. Then show me only the final result as JSON with keys renamed as 'api','method','inputs'"""
prompt = PromptTemplate(
      input_variables=['result','data','intent'],
      template=template
)
chain = LLMChain(llm=llm, prompt=prompt)
output_summary = chain.run({'result':result,'intent':intent,'data':data})
output_summary=json.loads(output_summary)
print(output_summary)
'''
 
#3
api=output_summary["api"]
data=output_summary["inputs"]
method=output_summary["method"]
print(api,data,method)
exec_api="Execute " +method+" method api from "+api+" using the data as json "+str(data)+" and show the api call output results neatly intended with 1 spaces"
print(exec_api)
agent_executor = create_python_agent(
    llm=llm,
    tool=PythonREPLTool(),
    verbose=True
)
out=agent_executor.run(exec_api)
print(out)
