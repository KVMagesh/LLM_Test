import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from ttkthemes import ThemedTk
import json

def on_faq_click(event, question):
    global prompt_textbox
    prompt_textbox.insert(tk.END, question + "\n")
    
def convert_to_json(hierarchy_str):
    key_value_pairs = hierarchy_str.split(" > ")
    # Splitting each pair at ' : ' to separate keys and values
    json_dict = {}
    for pair in key_value_pairs:
      key, value = pair.split(":")
      json_dict[key.strip()] = value.strip()
    # Convert dictionary to JSON string
    json_output = json.dumps(json_dict, indent=4)
    return json_output

def event_handler_wrapper(event):
    result = on_tree_select(event, input_textbox)
    print(result)
    
def on_tree_select(event,textbox):
    global input_textbox  # Declare input_textbox as global if it's not accessible
    selected_item = tree.focus()
    hierarchy = []
    selected_item = tree.focus()  # Get the selected item ID
    original_text = tree.item(selected_item, 'text') 
    while selected_item:
        item_text = tree.item(selected_item, 'text')  # Get the text of the selected item
        hierarchy.insert(0, item_text)  # Insert at the beginning to reverse the order
        selected_item = tree.parent(selected_item)  # Move up to the parent node

    # Format the hierarchy as a string
    hierarchy_str = " > ".join(hierarchy)
    
    json_data=convert_to_json(hierarchy_str)
    input_textbox.delete(1.0, tk.END)  # Clear the existing text
    input_textbox.insert(tk.END, original_text)  # Insert the text of the selected item
    return json_data

def clear():
    input_textbox.delete(1.0, tk.END)
    output_textbox.delete(1.0, tk.END)

# Save function to save the contents of the output text box to a file
def save():
    output_content = output_textbox.get(1.0, tk.END)
    with open("output.txt", "w") as file:
        file.write(output_content)
    messagebox.showinfo("Save", "Saved successfully")

def login():
    user_id = user_id_entry.get()
    password = password_entry.get()
    if user_id == 'test' and password == 'admin':
        for tab in range(1, book.index("end")):
            book.tab(tab, state='normal')
    else:
        messagebox.showerror("Error", "Invalid user ID or password")

def on_canvas_configure(event):
    canvas_width = event.width
    canvas_height = event.height
    canvas.itemconfig("container", width=canvas_width,height=canvas_height)
    canvas.config(scrollregion=canvas.bbox("all"))

def populate_tree(tree, parent, data):
    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, (dict, list)):
                # For nested dictionaries or lists, create a node for the key
                node = tree.insert(parent, 'end', text=key, open=True)
                populate_tree(tree, node, value)
            else:
                # For key-value pairs, insert both as text
                value_text = f"{key}: {value}"
                #print(value_text)
                tree.insert(parent, 'end', text=value_text)
    elif isinstance(data, list):
        for item in data:
            # For list items, handle them based on their type
            if isinstance(item, (dict, list)):
                populate_tree(tree, parent, item)
            else:
                # For simple list items, insert directly
                tree.insert(parent, 'end', text=str(item))
#root = tk.Tk()
root = ThemedTk(theme="adapta")
root.geometry("300x200")
root.title("Insurance Next Generation Assistant") 
book = ttk.Notebook(root)

login_tab = tk.Frame(book)
book.add(login_tab, text='   Login   ')

user_story_assistant_tab = tk.Frame(book)
Rules_Miner_tab = tk.Frame(book)
Reverse_Engineer_AI_tab = tk.Frame(book)
Prompt_Admin_tab = tk.Frame(book)
Product_Config_AI_tab = tk.Frame(book)
Specification_Summarizer_tab = tk.Frame(book)

book.add(user_story_assistant_tab, text ='                    User Story Assistant                    ') 
book.add(Rules_Miner_tab, text ='                    Rules Miner                    ') 
book.add(Reverse_Engineer_AI_tab, text ='                    Reverse Engineer AI                    ') 
book.add(Prompt_Admin_tab, text ='                    Prompt Admin                    ') 
book.add(Product_Config_AI_tab, text ='                    Product Config AI                    ') 
book.add(Specification_Summarizer_tab, text ='                    Specification Summarizer                    ') 

user_story_assistant_sub_notebook = ttk.Notebook(user_story_assistant_tab)
user_story_assistant_sub_notebook.pack(expand=True, fill='both')

# Create Step 1 and Step 2 tabs inside the sub-notebook
user_story_assistant_tab_step1 = tk.Frame(user_story_assistant_sub_notebook)
user_story_assistant_tab_step2 = tk.Frame(user_story_assistant_sub_notebook)

# Add Step 1 and Step 2 tabs to the sub-notebook
user_story_assistant_sub_notebook.add(user_story_assistant_tab_step1, text='   Step 1 : Start Your User Journey   ')
user_story_assistant_sub_notebook.add(user_story_assistant_tab_step2, text='   Step 2 : Align to Industry Standards  ')


# ... Adding other tabs to the notebook

#for tab in range(1, book.index("end")):
#    book.tab(tab, state='disabled')

book.pack(expand=True, fill='both')
login_frame = tk.Frame(login_tab)
login_frame.place(relx=0.5, rely=0.5, anchor='center')

# Login tab contents
user_id_label = tk.Label(login_frame, text="User ID:")
user_id_label.pack(pady=(10, 0))
user_id_entry = tk.Entry(login_frame)
user_id_entry.pack(pady=(0, 10))

password_label = tk.Label(login_frame, text="Password:")
password_label.pack()
password_entry = tk.Entry(login_frame, show="*")
password_entry.pack(pady=(0, 10))

login_button = tk.Button(login_frame, text="Login", command=login)
login_button.pack()


# Load your JSON data
sample_json = '''
{ 
  "Domain : Insurance":
  {
   "LOB : Life And Annuities":
    {
      "Process : New Business":
      { 
       "Sub Process : Underwriting":
        {
         "Functionality : Application capture":
          {
           "Epic_Name_1 : Annuity Application Management":
            { 
             "User_Story_1 : Annuity application details":
              {
               "User_Case_1" : "View and Manage Annuity Applications",
      	       "User_Case_2" : "Submit New Annuity Applications",
	           "User_Case_3" : "Check Application Status Updates",
               "User_Case_4" : "Update PAS" 
              },
	     "User_Story_2 :  Data and Third party Integration":
              {
               "User_Case_1" : "Store Annuity Applicant Details",
      	       "User_Case_2" : "API to Validate address information" 
	      },
	     "User_Story_3 : Client Communication ":
              {
               "User_Case_1" : "Manage Client Communications"
      	      }  
             }
           }
        }
      }
    }
  }
}    
'''

data = json.loads(sample_json)


# Canvas and Scrollbar for user_story_assistant_tab_step2
canvas = tk.Canvas(user_story_assistant_tab_step2)
scrollbar = tk.Scrollbar(user_story_assistant_tab_step2, command=canvas.xview, orient='horizontal')
v_scrollbar = tk.Scrollbar(user_story_assistant_tab_step2, command=canvas.xview, orient='vertical')
canvas.configure(xscrollcommand=scrollbar.set,yscrollcommand=v_scrollbar.set)

canvas.pack(side="top", fill="both", expand=True)
scrollbar.pack(side="bottom", fill="x")

# Container frame inside canvas
container_frame = tk.Frame(canvas)
canvas.create_window((0, 0), window=container_frame, anchor='nw', tags="container")
canvas.bind('<Configure>', on_canvas_configure)

# Configure grid layout for container frame
container_frame.columnconfigure(0, weight=1,uniform="column")
container_frame.columnconfigure(1, weight=1,uniform="column")
container_frame.columnconfigure(2, weight=1,uniform="column")
container_frame.rowconfigure(0, weight=1)  

# Frame 1 with Treeview
frame1 = tk.Frame(container_frame, bg='lightgrey',highlightbackground="black", highlightthickness=1)
frame1.grid(row=0, column=0, sticky='nsew')

style = ttk.Style()
style.configure("Treeview", background="lightgrey", fieldbackground="lightgrey")
style.configure("Treeview.Heading", background="lightgrey")  # Style for the headings
style.map("Treeview", background=[('selected', 'blue'), ('!selected', 'lightgrey')])

frame1 = tk.Frame(container_frame, bg='lightgrey')
frame1.grid(row=0, column=0, sticky='nsew')

frame1.columnconfigure(0, weight=1)
frame1.rowconfigure(0, weight=1)
# Create and pack Treeview
tree = ttk.Treeview(frame1,show='tree')


# Set the heading for the main column
tree.heading("#0", text="Category")

hierarchy_str=populate_tree(tree, '', data)
tree.grid(row=10, column=0, sticky='nsew')  
# Horizontal Scrollbar for Treeview
h_scrollbar = tk.Scrollbar(frame1, orient="horizontal", command=tree.xview)
h_scrollbar.grid(row=1, column=0, sticky='ew')

# Vertical Scrollbar for Treeview
v_scrollbar = tk.Scrollbar(frame1, orient="vertical", command=tree.yview)
v_scrollbar.grid(row=0, column=1, sticky='ns')
# Configure Treeview to use both scrollbars
tree.configure(xscrollcommand=h_scrollbar.set, yscrollcommand=v_scrollbar.set)
tree.grid(row=0, column=0, sticky='nsew')  

# Frame 2 inside container frame

frame2 = tk.Frame(container_frame, bg='lightgrey',highlightbackground="black", highlightthickness=1)
frame2.grid(row=0, column=1, sticky='nsew')
frame2.columnconfigure(0, weight=1)
frame2.rowconfigure(0, weight=1)
frame2.rowconfigure(1, weight=1)
frame2.rowconfigure(2, weight=0)
input_label = tk.Label(frame2, text="Describe Your User Story :",bg='lightgrey')
input_label.pack(side=tk.TOP, anchor='w', padx=10, pady=(5, 10))

input_textbox = tk.Text(frame2, wrap=tk.WORD, width=40, height=10)
input_textbox.pack(side=tk.TOP, fill='both', expand=True, padx=10, pady=(0, 5))

space_label = tk.Label(frame2, text="   ",bg='lightgrey')
space_label.pack(side=tk.TOP, anchor='w', padx=10, pady=(5, 10))

output_label = tk.Label(frame2, text="Converted User Story As Per Domain Standards :",bg='lightgrey')
output_label.pack(side=tk.TOP, anchor='w', padx=10, pady=(5, 10))

output_textbox = tk.Text(frame2, wrap=tk.WORD, width=40, height=10, state='disabled')
output_textbox.pack(side=tk.TOP, fill='both', expand=True, padx=10, pady=(0, 5))

# Add buttons at the bottom
button_frame = tk.Frame(frame2, bg='lightgrey')
button_frame.pack(side=tk.BOTTOM, fill='x', padx=10, pady=(5, 10))

save_button = tk.Button(button_frame, text="Save")
save_button.pack(side='left', padx=10, pady=10)

clear_button = tk.Button(button_frame, text="Clear", command=clear)
clear_button.pack(side='left', padx=10, pady=10)

#tree.bind('<<TreeviewSelect>>', lambda event: on_tree_select(event, input_textbox))
tree.bind('<<TreeviewSelect>>', event_handler_wrapper)

# Frame 3 with Dropdowns, FAQ, and Prompt Input
frame3 = tk.Frame(container_frame, bg='lightgrey', highlightbackground="black", highlightthickness=1)
frame3.grid(row=0, column=2, sticky='nsew')
frame3.columnconfigure(0, weight=1)
frame3.rowconfigure([0, 2, 4, 6], weight=5)  # Adjust rows for labels, dropdowns, spacing, and textbox

# Step 1: Domain Model Label and Dropdown
domain_label = tk.Label(frame3, text="Select your domain model", bg='lightgrey')
domain_label.grid(row=0, column=0, sticky='w', padx=10, pady=(10, 0))

domain_options = ["","Accord For Life and Annuities", "Accord for P&C", "Accord for Health", "Accord Re-insurance"]  # Replace with actual options
domain_dropdown = ttk.Combobox(frame3, values=domain_options, width=30)
domain_dropdown.grid(row=1, column=0, padx=(10, 0), pady=(10, 10), sticky='w')  # Added pady for spacing

# Step 3: Gen AI Model Label and Dropdown
gen_ai_label = tk.Label(frame3, text="Select your Gen AI model  ", bg='lightgrey')
gen_ai_label.grid(row=3, column=0, sticky='w', padx=10, pady=(10, 0))

gen_ai_options = ["","GPT-3.5", "GPT-4.0", "LLAMA 2","CLAUDE 2","TITAN","GEMINI","BARD"]  # Replace with actual AI model options
gen_ai_dropdown = ttk.Combobox(frame3, values=gen_ai_options, width=30)
gen_ai_dropdown.grid(row=4, column=0, padx=(10, 0), pady=(10, 10), sticky='w')  # Added pady for spacing

# FAQ Label
faq_label = tk.Label(frame3, text="FAQ :", bg='lightgrey')
faq_label.grid(row=6, column=0, sticky='w', padx=10, pady=(10, 0))

# FAQ Questions as Hyperlinks
faq_questions = ["Question 1", "Question 2", "Question 3", "Question 4", "Question 5"]  # Replace with actual questions
for i, question in enumerate(faq_questions, start=7):
    question_label = tk.Label(frame3, text=question, fg="blue", cursor="hand2", bg='lightgrey')
    question_label.grid(row=i, column=0, padx=10, pady=(0, 10), sticky='w')
    question_label.bind("<Button-1>", lambda event, q=question: on_faq_click(event, q))

# Prompt Label and Textbox
prompt_label = tk.Label(frame3, text="Enter your prompt", bg='lightgrey')
prompt_label.grid(row=13, column=0, sticky='w', padx=10, pady=(10, 0))

prompt_textbox = tk.Text(frame3, wrap=tk.WORD, height=5)
prompt_textbox.grid(row=14, column=0, padx=10, pady=(0, 10), sticky='ew')

# Submit Button
submit_button = tk.Button(frame3, text="Submit your prompt")
submit_button.grid(row=15, column=0, padx=10, pady=(0, 10))


root.mainloop()
