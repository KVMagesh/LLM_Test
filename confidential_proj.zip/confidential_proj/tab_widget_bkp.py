import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from ttkthemes import ThemedTk
import json

def clear():
    input_textbox.delete(1.0, tk.END)
    output_textbox.delete(1.0, tk.END)

# Save function to save the contents of the output text box to a file
def save():
    output_content = output_textbox.get(1.0, tk.END)
    with open("output.txt", "w") as file:
        file.write(output_content)
    messagebox.showinfo("Save", "Saved successfully")

def login():
    user_id = user_id_entry.get()
    password = password_entry.get()
    if user_id == 'test' and password == 'admin':
        for tab in range(1, book.index("end")):
            book.tab(tab, state='normal')
    else:
        messagebox.showerror("Error", "Invalid user ID or password")

def update_scrollregion(event):
    canvas.configure(scrollregion=canvas.bbox("all"))

def on_canvas_configure(event):
    canvas_width = event.width
    canvas_height = event.height
    canvas.itemconfig("container", width=canvas_width,height=canvas_height)
    canvas.config(scrollregion=canvas.bbox("all"))

def populate_tree(tree, parent, data):
    for key, value in data.items():
        if isinstance(value, dict):
            # Create a node for the dictionary and recursively add its values
            node = tree.insert(parent, 'end', text=key, open=True)
            populate_tree(tree, node, value)
        elif isinstance(value, list):
            # Create nodes for each item in the list
            node = tree.insert(parent, 'end', text=key, open=True)
            for item in value:
                populate_tree(tree, node, item)
        else:
            # Insert the value directly as a leaf node
            tree.insert(parent, 'end', text=str(value))


#root = tk.Tk()
root = ThemedTk(theme="adapta")
root.geometry("300x200")
root.title("Insurance Next Generation Assistant") 
book = ttk.Notebook(root)

login_tab = tk.Frame(book)
book.add(login_tab, text='   Login   ')

tab1 = tk.Frame(book)
tab2 = tk.Frame(book)
tab3 = tk.Frame(book)
tab4 = tk.Frame(book)
tab5 = tk.Frame(book)
tab6 = tk.Frame(book)

book.add(tab1, text ='                    User Story Assistant                    ') 
book.add(tab2, text ='                    Rules Miner                    ') 
book.add(tab3, text ='                    Reverse Engineer AI                    ') 
book.add(tab4, text ='                    Prompt Admin                    ') 
book.add(tab5, text ='                    Product Config AI                    ') 
book.add(tab6, text ='                    Specification Summarizer                    ') 

# ... Adding other tabs to the notebook

#for tab in range(1, book.index("end")):
#    book.tab(tab, state='disabled')

book.pack(expand=True, fill='both')
login_frame = tk.Frame(login_tab)
login_frame.place(relx=0.5, rely=0.5, anchor='center')

# Login tab contents
user_id_label = tk.Label(login_frame, text="User ID:")
user_id_label.pack(pady=(10, 0))
user_id_entry = tk.Entry(login_frame)
user_id_entry.pack(pady=(0, 10))

password_label = tk.Label(login_frame, text="Password:")
password_label.pack()
password_entry = tk.Entry(login_frame, show="*")
password_entry.pack(pady=(0, 10))

login_button = tk.Button(login_frame, text="Login", command=login)
login_button.pack()


# Load your JSON data
sample_json ='''
{ 
  "Domain - Insurance":
  {
   "LOB - Life And Annuities":
    {
      "Process - New Business":
      { 
       "Sub Process - Underwriting":
        {
         "Functionality - Application capture":
          {
           "Epic_Name_1 - Annuity Application Management":
            { 
             "User_Story_1 - Access and Review annuity application details":
              {
               "User_Case_1" :"1.View and Manage Annuity Applications",
      	       "User_Case_2" :"2.Submit New Annuity Applications",
	           "User_Case_3" :"3.Track Application Status Updates" 
              },
	     "User_Story_2 -  Data and Third party Integration":
              {
               "User_Case_1":"1.Store Annuity Applicant Details",
      	       "User_Case_2":"2.Validate address and Zip code details from 3rd party services thru API" 
	      },
	     "User_Story_3-  Client Communication for Annuity Applications":
              {
               "User_Case_1":"1.Manage Client Communications and Notifications"
      	      }  
             }
           }
        }
      }
    }
  }
}    
'''
data = json.loads(sample_json)

# Canvas and Scrollbar for tab1
canvas = tk.Canvas(tab1)
scrollbar = tk.Scrollbar(tab1, command=canvas.xview, orient='horizontal')
canvas.configure(xscrollcommand=scrollbar.set)

canvas.pack(side="top", fill="both", expand=True)
scrollbar.pack(side="bottom", fill="x")

# Container frame inside canvas
container_frame = tk.Frame(canvas)
canvas.create_window((0, 0), window=container_frame, anchor='nw', tags="container")
canvas.bind('<Configure>', on_canvas_configure)

# Configure grid layout for container frame
container_frame.columnconfigure(0, weight=1,uniform="column")
container_frame.columnconfigure(1, weight=1,uniform="column")
container_frame.columnconfigure(2, weight=1,uniform="column")
container_frame.rowconfigure(0, weight=1)  

# Frame 1 with Treeview
frame1 = tk.Frame(container_frame, bg='lightgrey',highlightbackground="black", highlightthickness=1)
frame1.grid(row=0, column=0, sticky='nsew')

style = ttk.Style()
style.configure("Treeview", background="lightgrey", fieldbackground="lightgrey")
style.configure("Treeview.Heading", background="lightgrey")  # Style for the headings
style.map("Treeview", background=[('selected', 'blue'), ('!selected', 'lightgrey')])

frame1 = tk.Frame(container_frame, bg='lightgrey')
frame1.grid(row=0, column=0, sticky='nsew')

frame1.columnconfigure(0, weight=1)
frame1.rowconfigure(0, weight=1)

# Create and pack Treeview
tree = ttk.Treeview(frame1)
populate_tree(tree, '', data)
tree.grid(row=0, column=0, sticky='nsew')  

# Frame 2 inside container frame
frame2 = tk.Frame(container_frame, bg='lightgrey',highlightbackground="black", highlightthickness=1)
frame2.grid(row=0, column=1, sticky='nsew')
# Horizontal Scrollbar for Treeview
h_scrollbar = tk.Scrollbar(frame1, orient="horizontal", command=tree.xview)
h_scrollbar.grid(row=1, column=0, sticky='ew')

# Vertical Scrollbar for Treeview
v_scrollbar = tk.Scrollbar(frame1, orient="vertical", command=tree.yview)
v_scrollbar.grid(row=0, column=1, sticky='ns')
# Configure Treeview to use both scrollbars
tree.configure(xscrollcommand=h_scrollbar.set, yscrollcommand=v_scrollbar.set)
tree.grid(row=0, column=0, sticky='nsew')  
tree.bind("<Configure>", update_scrollregion)

frame2.columnconfigure(0, weight=1)
frame2.rowconfigure(0, weight=1)
frame2.rowconfigure(1, weight=1)
frame2.rowconfigure(2, weight=0)


input_label = tk.Label(frame2, text="Describe Your User Story :",bg='lightgrey')
input_label.pack(side=tk.TOP, anchor='w', padx=10, pady=(5, 10))

input_textbox = tk.Text(frame2, wrap=tk.WORD, width=40, height=10)
input_textbox.pack(side=tk.TOP, fill='both', expand=True, padx=10, pady=(0, 5))

space_label = tk.Label(frame2, text="   ",bg='lightgrey')
space_label.pack(side=tk.TOP, anchor='w', padx=10, pady=(5, 10))

output_label = tk.Label(frame2, text="Converted User Story As Per Domain Standards :",bg='lightgrey')
output_label.pack(side=tk.TOP, anchor='w', padx=10, pady=(5, 10))

output_textbox = tk.Text(frame2, wrap=tk.WORD, width=40, height=10, state='disabled')
output_textbox.pack(side=tk.TOP, fill='both', expand=True, padx=10, pady=(0, 5))

# Add buttons at the bottom
button_frame = tk.Frame(frame2, bg='lightgrey')
button_frame.pack(side=tk.BOTTOM, fill='x', padx=10, pady=(5, 10))

save_button = tk.Button(button_frame, text="Save")
save_button.pack(side='left', padx=10, pady=10)

clear_button = tk.Button(button_frame, text="Clear", command=clear)
clear_button.pack(side='left', padx=10, pady=10)

root.mainloop()
