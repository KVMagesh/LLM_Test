import json

# Given string
json_string = "Domain : Insurance > LOB : Life And Annuities > Process : New Business > Sub Process : Underwriting > Functionality : Application capture > Epic_Name_1 : Annuity Application Management > User_Story_1 : Annuity application details > User_Case_1 : View and Manage Annuity Applications"

# Convert string to dictionary
# Splitting the string at ' > ' to separate each key-value pair
key_value_pairs = json_string.split(" > ")

# Splitting each pair at ' : ' to separate keys and values
json_dict = {}
for pair in key_value_pairs:
    key, value = pair.split(" : ")
    json_dict[key.strip()] = value.strip()

# Convert dictionary to JSON string
json_output = json.dumps(json_dict, indent=4)

print(json_output)
