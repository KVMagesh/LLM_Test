# -*- coding: utf-8 -*-
"""
Created on Sat Jul  8 09:15:13 2023

@author: Mahesh
"""

from langchain.embeddings import OpenAIEmbeddings 
from langchain.vectorstores import Chroma 
from dotenv import load_dotenv, find_dotenv
from langchain.document_loaders import PyPDFDirectoryLoader
import os
from langchain.text_splitter import RecursiveCharacterTextSplitter

#load_dotenv(find_dotenv(),override=True)
#OPENAI_API_KEY=os.environ.get('OPENAI_API_KEY')
OPENAI_API_KEY="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"

folder = './pdf/Insurance_API'
#folder = './pdf'
sub_folders = [name for name in os.listdir(folder) if os.path.isdir(os.path.join(folder, name))]
for folder in sub_folders:
    print('going to folder --->',folder)
    directory = os.path.join(os.getcwd(), r'pdf/Insurance_API',folder)
    #directory = os.path.join(os.getcwd(), r'pdf',folder)
  
    if len(os.listdir(directory)) == 0:
        print("Empty directory :  ",directory)
    else:
        print("Not empty directory :",directory)
        loader = PyPDFDirectoryLoader(directory)
        docs = loader.load()
        print(docs)
        collection_name=folder
        persist_directory="./Knowledge Base/"+collection_name
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
        documents = text_splitter.split_documents(docs)
        embeddings = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)
        vectordb = Chroma.from_documents(documents, embedding=embeddings,collection_name=collection_name, 
                                      persist_directory=persist_directory)
        vectordb.persist()
     
